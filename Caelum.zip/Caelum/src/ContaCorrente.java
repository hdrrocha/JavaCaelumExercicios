	
	public abstract class ContaCorrente extends Conta{
		
	}